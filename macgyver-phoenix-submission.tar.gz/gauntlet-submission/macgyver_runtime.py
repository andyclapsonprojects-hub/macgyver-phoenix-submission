"""Construct the official clients for one MacGyver competition run."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from arena_clients import (
    HttpArenaClient,
    McpArenaClient,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
)
from arena_clients.config import agent_id_problem
from arena_clients.proxy_headers import build_proxy_headers
from controller import ControllerOutcome, ThorntonController
from macgyver_strategy import MacGyverStrategy
from model_selector import fetch_available_models
from private_puzzle_recorder import PrivatePuzzleRecorder

REPO_ROOT = Path(__file__).resolve().parent


async def run_connected(*, resume: bool = False) -> ControllerOutcome:
    """Create official clients and run or resume exactly one registered session."""
    load_dotenv(REPO_ROOT / ".env")
    strategy = MacGyverStrategy()
    agent_id = str(os.getenv("AGENT_ID") or strategy.agent_id).strip()
    agent_name = str(os.getenv("AGENT_NAME") or strategy.agent_name).strip()
    problem = agent_id_problem(agent_id)
    if problem:
        raise SystemExit(problem)
    os.environ["AGENT_ID"] = agent_id
    os.environ["AGENT_NAME"] = agent_name

    ensure_connected()
    api_key = get_arena_api_key()
    proxy_host = get_proxy_host()
    http_client = HttpArenaClient(get_api_base(), api_key)

    try:
        from openai import OpenAI
    except ImportError as error:
        raise RuntimeError("The locked runtime is missing the openai package") from error

    def llm_client_factory(usage_scope: str | None) -> Any:
        return OpenAI(
            base_url=proxy_host,
            api_key=api_key,
            default_headers=build_proxy_headers(agent_id, usage_scope),
        )

    async with McpArenaClient(get_mcp_url()) as mcp_client:
        controller = ThorntonController(
            strategy=strategy,
            http_client=http_client,
            mcp_client=mcp_client,
            llm_client_factory=llm_client_factory,
            fetch_models=lambda: fetch_available_models(proxy_host, api_key),
            agent_id=agent_id,
            agent_name=agent_name,
            puzzle_recorder=PrivatePuzzleRecorder.from_environment(REPO_ROOT),
        )
        outcome = await controller.run(register_session=not resume)
    print(f"Status: submitted ({outcome.modality})")
    print(f"Model: {outcome.model_name}")
    return outcome

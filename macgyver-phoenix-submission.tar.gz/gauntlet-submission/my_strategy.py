"""Starter-kit compatibility adapter for the MacGyver strategy."""

from __future__ import annotations

import importlib
from typing import cast

from base_strategy import BaseStrategy

try:
    _strategy_module = importlib.import_module("macgyver_strategy")
    _StrategyBase = cast(type[BaseStrategy], _strategy_module.MacGyverStrategy)
except ImportError:  # Keep the organiser's default package independently runnable.
    _StrategyBase = BaseStrategy


class MyStrategy(_StrategyBase):  # type: ignore[misc, valid-type]
    """Expose ``MacGyverStrategy`` under the name expected by starter-kit agents."""


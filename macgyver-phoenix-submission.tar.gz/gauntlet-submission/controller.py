"""Small autonomous controller that owns the Gauntlet run lifecycle."""

from __future__ import annotations

import asyncio
import json
from collections.abc import Awaitable, Callable, Iterable
from dataclasses import dataclass
from functools import partial
from typing import Any

from answer_validator import AnswerModality, RileyValidator
from arena_clients import (
    ArenaAPIError,
    ArenaConnectionError,
    McpArenaClient,
    McpArenaError,
)
from base_strategy import ChallengeContext
from loop_guard import ActionKind, GuardedAction, LoopGuard
from model_selector import require_explicit_model
from private_puzzle_recorder import PrivatePuzzleRecorder
from solver import DecisionKind, MacGyverSolver, SolverResponseError
from task_ledger import PhoenixLedger
from tool_policy import DaltonToolScout, DiscoveredTool, ToolPolicyError

_CONTROLLER_OWNED_TOOLS = {
    "arena.get_challenge",
    "arena.clues.list",
    "arena.clues.get",
    "arena.time_remaining",
    "arena.image.get_challenge",
    "arena.image.broadcast_thought",
    "arena.image.submit_edit",
}


@dataclass(frozen=True)
class ControllerOutcome:
    """Final local record of one controller run."""

    modality: str
    challenge_type: str
    puzzle_id: str
    answer: str
    model_name: str
    submitted: bool
    receipt: Any
    ledger: PhoenixLedger


class ThorntonController:
    """Coordinate discovery, guarded work, verification, and final submission."""

    def __init__(
        self,
        *,
        strategy: Any,
        http_client: Any,
        mcp_client: Any,
        llm_client_factory: Callable[[str | None], Any],
        fetch_models: Callable[[], list[str]],
        detect_modality: Callable[[list[str], str], str] | None = None,
        agent_id: str,
        agent_name: str,
        guard: LoopGuard | None = None,
        validator: RileyValidator | None = None,
        puzzle_recorder: PrivatePuzzleRecorder | None = None,
        max_steps: int = 12,
    ) -> None:
        self.strategy = strategy
        self.http = http_client
        self.mcp = mcp_client
        self.llm_client_factory = llm_client_factory
        self.fetch_models = fetch_models
        self.detect_modality = detect_modality or (
            lambda tools, agent_id: McpArenaClient.detect_modality(tools, agent_id=agent_id)
        )
        self.agent_id = agent_id
        self.agent_name = agent_name
        self.guard = guard or LoopGuard()
        self.validator = validator or RileyValidator()
        self.puzzle_recorder = puzzle_recorder
        self.max_steps = max(1, max_steps)

    async def run(self, *, register_session: bool = True) -> ControllerOutcome:
        """Run one challenge, optionally resuming an already registered session."""
        if register_session:
            registration = GuardedAction("register", {}, ActionKind.REGISTER)
            decision = self.guard.check(registration, evidence_version=0)
            if not decision.allowed:
                raise RuntimeError(decision.reason)
            await asyncio.to_thread(self.http.register, self.agent_id, self.agent_name)
            self.guard.record_registration()

        usage_scope = await self._optional_http(self.http.fetch_usage_scope)
        llm_client = self.llm_client_factory(
            str(usage_scope).strip() if usage_scope else None
        )
        available_models = await self._read_with_retry(
            lambda: asyncio.to_thread(self.fetch_models)
        )

        tool_names = await self._read_with_retry(self.mcp.list_tools)
        tool_defs = await self._read_with_retry(self.mcp.list_tool_defs)
        modality = self.detect_modality(tool_names, self.agent_id)
        scout = DaltonToolScout.from_runtime_definitions(tool_defs)
        discovered_tools = self._discovered_tools(tool_defs)

        if modality == "image":
            return await self._run_image(
                scout,
                discovered_tools,
                tool_defs,
                available_models,
            )
        return await self._run_text(
            scout,
            discovered_tools,
            available_models,
            llm_client,
        )

    async def _run_text(
        self,
        scout: DaltonToolScout,
        discovered_tools: list[DiscoveredTool],
        available_models: list[str],
        llm_client: Any,
    ) -> ControllerOutcome:
        challenge = await self._read_with_retry(
            lambda: self.mcp.get_challenge(self.agent_id)
        )
        required_tools = self._string_set(getattr(challenge, "required_tools", []))
        ledger = PhoenixLedger(challenge.description)
        ledger.activate()
        ledger.require_tools(sorted(required_tools))
        self._record_controller_tool(ledger, "arena.get_challenge", "Challenge received")

        clue_ids = await self._read_with_retry(
            lambda: self.mcp.list_clues(self.agent_id)
        )
        self._record_controller_tool(ledger, "arena.clues.list", f"{len(clue_ids)} clues listed")
        recorded_clues: list[dict[str, str]] = []
        for clue_id in clue_ids:
            clue = await self._read_with_retry(
                partial(self.mcp.get_clue, clue_id, self.agent_id)
            )
            ledger.add_evidence(clue.text)
            recorded_clues.append({"clue_id": str(clue_id), "text": str(clue.text)})
            self._record_controller_tool(ledger, "arena.clues.get", clue.text[:500])
        for clue_text in challenge.clues:
            ledger.add_evidence(str(clue_text))
        ledger.add_evidence(str(getattr(challenge, "extra_text", "") or ""))
        if self.puzzle_recorder is not None:
            self.puzzle_recorder.start_text(
                agent_id=self.agent_id,
                challenge=challenge,
                clues=recorded_clues,
            )

        await self._optional_http(
            self.http.broadcast_thought,
            self.agent_id,
            "MacGyver Agent is mapping the challenge and discovered tools.",
        )

        solver = MacGyverSolver(self.strategy, llm_client)
        model_name = ""
        total_tokens = 0
        candidate_tools = [
            tool for tool in discovered_tools if tool.name not in _CONTROLLER_OWNED_TOOLS
        ]
        solver_recovery_used = False

        for _ in range(self.max_steps):
            remaining_s = await self._time_remaining(ledger)
            if self.guard.should_submit(remaining_s, has_candidate=bool(ledger.candidate_answer)):
                break
            timeout_s = self.guard.call_timeout(remaining_s)
            if timeout_s <= 0:
                break

            ctx = self._text_context(challenge, ledger, available_models, remaining_s, total_tokens)
            try:
                proposal = await solver.decide(
                    ctx,
                    ledger,
                    candidate_tools,
                    available_models,
                    timeout_s=timeout_s,
                )
            except (SolverResponseError, TimeoutError):
                if solver_recovery_used:
                    break
                solver_recovery_used = True
                continue
            model_name = proposal.model_name
            total_tokens += proposal.total_tokens

            if proposal.kind is DecisionKind.ANSWER:
                shape = self.validator.validate_text(proposal.answer)
                if not shape.valid:
                    continue
                ledger.set_candidate(shape.normalized_answer)
                validation = self.validator.validate_text(
                    shape.normalized_answer,
                    required_tools=ledger.required_tools,
                    used_tools=ledger.used_tools,
                )
                if validation.valid:
                    ledger.set_candidate(validation.normalized_answer)
                    ledger.mark_solved()
                    break
                # A useful candidate is retained while required tool work continues.
                if not ledger.missing_required_tools():
                    continue
                continue

            action = GuardedAction(
                proposal.tool_name,
                dict(proposal.arguments or {}),
                ActionKind.CAPABILITY,
            )
            guard_decision = self.guard.check(action, evidence_version=len(ledger.evidence))
            if not guard_decision.allowed:
                continue
            before = len(ledger.evidence)
            try:
                scout.validate_action(action.name, action.arguments)
                call_timeout = self.guard.call_timeout(remaining_s)
                result = await asyncio.wait_for(
                    self.mcp.call_tool(action.name, action.arguments),
                    timeout=max(0.1, call_timeout),
                )
                summary = self._result_summary(result)
                succeeded = self._tool_result_succeeded(result)
                ledger.record_tool_action(
                    action.name,
                    action.arguments,
                    succeeded=succeeded,
                    result_summary=summary,
                )
                if summary:
                    ledger.add_evidence(f"{action.name}: {summary}")
            except (TimeoutError, ToolPolicyError, McpArenaError, OSError, RuntimeError) as error:
                ledger.record_tool_action(
                    action.name,
                    action.arguments,
                    succeeded=False,
                    result_summary=f"{type(error).__name__}: {error}",
                )
                succeeded = False
            self.guard.record_result(
                action,
                succeeded=succeeded,
                evidence_version=len(ledger.evidence),
            )
            if len(ledger.evidence) == before and not succeeded:
                continue

        answer = ledger.candidate_answer.strip()
        if not answer:
            answer = "No valid answer was produced before the submission reserve."
        await self._optional_http(self.http.save_draft, self.agent_id, answer, "Verified candidate")
        await self._optional_http(
            self.http.broadcast_thought,
            self.agent_id,
            "Submitting the strongest available candidate before the deadline.",
        )
        receipt = await self._submit_text(answer, model_name, total_tokens)
        if self.puzzle_recorder is not None:
            self.puzzle_recorder.finish(
                answer=answer,
                model_name=model_name,
                receipt=receipt,
            )
        return ControllerOutcome(
            modality="text",
            challenge_type=str(challenge.challenge_type),
            puzzle_id=str(challenge.puzzle_id),
            answer=answer,
            model_name=model_name,
            submitted=True,
            receipt=receipt,
            ledger=ledger,
        )

    async def _read_with_retry(
        self,
        operation: Callable[[], Awaitable[Any]],
    ) -> Any:
        """Retry one idempotent external read once after a transient failure."""

        for attempt in range(2):
            try:
                return await operation()
            except McpArenaError as error:
                if error.is_terminal or attempt == 1:
                    raise
            except (TimeoutError, OSError):
                if attempt == 1:
                    raise
            await asyncio.sleep(0)
        raise RuntimeError("MCP read retry loop ended unexpectedly")

    async def _run_image(
        self,
        scout: DaltonToolScout,
        discovered_tools: list[DiscoveredTool],
        tool_defs: list[Any],
        available_models: list[str],
    ) -> ControllerOutcome:
        challenge = await self._read_with_retry(
            lambda: self.mcp.get_image_challenge(self.agent_id)
        )
        if self.puzzle_recorder is not None:
            self.puzzle_recorder.start_image(
                agent_id=self.agent_id,
                challenge=challenge,
            )
        required_tools = self._string_set(getattr(challenge, "required_tools", []))
        ledger = PhoenixLedger(challenge.description)
        ledger.activate()
        ledger.require_tools(sorted(required_tools))
        self._record_controller_tool(ledger, "arena.image.get_challenge", "Image challenge received")

        ctx = ChallengeContext(
            challenge_type=challenge.challenge_type,
            challenge_text=str(challenge.prompt or "").strip(),
            description=challenge.description,
            # Reference notes are constraints, not a second primary instruction.
            rules=str(challenge.reference_notes or "").strip(),
            time_remaining_s=challenge.time_remaining_s,
            max_time_s=challenge.max_time_s,
            available_models=list(available_models),
            required_tools=sorted(required_tools),
            image_url=challenge.input_image_uri or None,
        )
        ranked = self.strategy.rank_models(ctx, available_models)
        model_name = require_explicit_model(
            self.strategy.pick_model("solve", ranked, ctx),
            available_models,
            source="ThorntonController image path",
        )
        image_tools = [
            tool.name
            for tool in discovered_tools
            if tool.name in {"image_edit", "image_generate", "image_analyze"}
        ]
        selected_tool = self.strategy.plan_image_tool(ctx, image_tools)
        if selected_tool not in {"image_edit", "image_generate"}:
            raise RuntimeError("No discovered image output tool can satisfy this challenge")

        await self.mcp.broadcast_image_thought(
            "MacGyver Agent selected a bounded image route and will verify its output.",
            agent_id=self.agent_id,
        )
        self._record_controller_tool(
            ledger,
            "arena.image.broadcast_thought",
            "Progress thought broadcast",
        )

        prompt = self.strategy.build_image_prompt(ctx)
        arguments = self._image_arguments(
            selected_tool,
            tool_defs,
            prompt=prompt,
            input_image_uri=challenge.input_image_uri,
            model_name=model_name,
        )
        action = GuardedAction(selected_tool, arguments)
        guard_decision = self.guard.check(action, evidence_version=0)
        if not guard_decision.allowed:
            raise RuntimeError(guard_decision.reason)
        scout.validate_action(selected_tool, arguments)
        remaining_s = float(challenge.time_remaining_s)
        timeout_s = self.guard.call_timeout(remaining_s, preferred_s=60)
        if timeout_s <= 0:
            raise TimeoutError("No arena time remains for an image tool call")
        try:
            result = await asyncio.wait_for(
                self.mcp.call_tool(selected_tool, arguments),
                timeout=timeout_s,
            )
            if not self._tool_result_succeeded(result):
                raise RuntimeError("Image tool returned an explicit failure")
            output_uri = (
                str(result.get("image_uri") or "").strip()
                if isinstance(result, dict)
                else ""
            )
            if not output_uri:
                raise RuntimeError("Image tool returned no output URI")
            summary = self._result_summary(result)
            ledger.record_tool_action(
                selected_tool,
                arguments,
                succeeded=True,
                result_summary=summary,
            )
            self.guard.record_result(action, succeeded=True, evidence_version=1)
        except (TimeoutError, McpArenaError, OSError, RuntimeError) as error:
            ledger.record_tool_action(
                selected_tool,
                arguments,
                succeeded=False,
                result_summary=f"{type(error).__name__}: {error}",
            )
            self.guard.record_result(action, succeeded=False, evidence_version=0)
            result = {}

        output_uri = str(result.get("image_uri") or "").strip() if isinstance(result, dict) else ""
        modality = (
            AnswerModality.IMAGE_EDIT
            if selected_tool == "image_edit"
            else AnswerModality.IMAGE_GENERATE
        )
        validation = self.validator.validate_image(
            output_uri,
            modality=modality,
            input_image_uri=challenge.input_image_uri,
            required_tools=ledger.required_tools,
            used_tools=ledger.used_tools,
        )
        if not validation.valid:
            raise RuntimeError("; ".join(validation.errors))
        ledger.set_candidate(validation.normalized_answer)
        ledger.mark_solved()

        receipt = await self._submit_image(validation.normalized_answer, model_name)
        if self.puzzle_recorder is not None:
            self.puzzle_recorder.finish(
                answer=validation.normalized_answer,
                model_name=model_name,
                receipt=receipt,
            )
        return ControllerOutcome(
            modality="image",
            challenge_type=str(challenge.challenge_type),
            puzzle_id=str(challenge.puzzle_id),
            answer=validation.normalized_answer,
            model_name=model_name,
            submitted=True,
            receipt=receipt,
            ledger=ledger,
        )

    async def _submit_text(self, answer: str, model_name: str, total_tokens: int) -> Any:
        action = GuardedAction("submit", {"answer": answer}, ActionKind.SUBMIT)
        receipt: Any
        try:
            receipt = await asyncio.to_thread(
                self.http.submit,
                self.agent_id,
                answer,
                {"model_name": model_name, "total_tokens": str(total_tokens)},
            )
            self.guard.record_submission(answer, delivery_confirmed=True)
            return receipt
        except (ArenaConnectionError, TimeoutError, OSError):
            self.guard.record_submission(answer, delivery_confirmed=False)
        retry = self.guard.check(action, evidence_version=0)
        if not retry.allowed:
            raise RuntimeError(retry.reason)
        receipt = await asyncio.to_thread(
            self.http.submit,
            self.agent_id,
            answer,
            {"model_name": model_name, "total_tokens": str(total_tokens)},
        )
        self.guard.record_submission(answer, delivery_confirmed=True)
        return receipt

    async def _submit_image(self, image_uri: str, model_name: str) -> Any:
        action = GuardedAction("submit", {"answer": image_uri}, ActionKind.SUBMIT)
        try:
            receipt = await self.mcp.submit_image(
                agent_id=self.agent_id,
                image_uri=image_uri,
                client_metrics={"model_name": model_name, "planner_tool": "image"},
                rationale="MacGyver Agent verified image route",
            )
            self.guard.record_submission(image_uri, delivery_confirmed=True)
            return receipt
        except McpArenaError as error:
            if error.is_terminal:
                raise
            self.guard.record_submission(image_uri, delivery_confirmed=False)
        except (TimeoutError, OSError, RuntimeError):
            self.guard.record_submission(image_uri, delivery_confirmed=False)
        retry = self.guard.check(action, evidence_version=0)
        if not retry.allowed:
            raise RuntimeError(retry.reason)
        receipt = await self.mcp.submit_image(
            agent_id=self.agent_id,
            image_uri=image_uri,
            client_metrics={"model_name": model_name, "planner_tool": "image"},
            rationale="Exact retry after uncertain delivery",
        )
        self.guard.record_submission(image_uri, delivery_confirmed=True)
        return receipt

    async def _time_remaining(self, ledger: PhoenixLedger) -> float:
        info = await self._read_with_retry(
            lambda: self.mcp.time_remaining(self.agent_id)
        )
        self._record_controller_tool(ledger, "arena.time_remaining", "Timer refreshed")
        return float(info.get("time_remaining_s", 0.0))

    @staticmethod
    async def _optional_http(function: Callable[..., Any], *args: Any) -> Any:
        """Keep non-final telemetry from killing an otherwise valid run."""
        try:
            return await asyncio.to_thread(function, *args)
        except (ArenaAPIError, ArenaConnectionError, TimeoutError, OSError, RuntimeError):
            return None

    @staticmethod
    def _record_controller_tool(ledger: PhoenixLedger, name: str, summary: str) -> None:
        if name in ledger.required_tools:
            ledger.record_tool_action(name, {}, succeeded=True, result_summary=summary)

    @staticmethod
    def _string_set(value: Any) -> set[str]:
        if not isinstance(value, (list, tuple, set)):
            return set()
        return {str(item).strip() for item in value if str(item).strip()}

    @staticmethod
    def _discovered_tools(definitions: Iterable[Any]) -> list[DiscoveredTool]:
        tools: list[DiscoveredTool] = []
        for definition in definitions:
            if isinstance(definition, dict):
                name = str(definition.get("name") or "").strip()
                schema = definition.get("inputSchema") or definition.get("input_schema") or {}
            else:
                name = str(getattr(definition, "name", "") or "").strip()
                schema = (
                    getattr(definition, "inputSchema", None)
                    or getattr(definition, "input_schema", None)
                    or {}
                )
            if name and isinstance(schema, dict):
                tools.append(DiscoveredTool(name, schema))
        return tools

    @staticmethod
    def _result_summary(result: Any) -> str:
        if result is None:
            return ""
        if isinstance(result, str):
            return result[:2000]
        try:
            return json.dumps(result, ensure_ascii=False, default=str)[:2000]
        except (TypeError, ValueError):
            return str(result)[:2000]

    @staticmethod
    def _tool_result_succeeded(result: Any) -> bool:
        """Treat explicit MCP error payloads as failed capability attempts."""

        if not isinstance(result, dict):
            return True
        if result.get("isError") is True or result.get("is_error") is True:
            return False
        return not bool(result.get("error"))

    @staticmethod
    def _text_context(
        challenge: Any,
        ledger: PhoenixLedger,
        available_models: list[str],
        remaining_s: float,
        tokens_used: int,
    ) -> ChallengeContext:
        return ChallengeContext(
            challenge_type=challenge.challenge_type,
            challenge_text=challenge.description,
            description=challenge.description,
            rules=challenge.rules,
            clues=list(ledger.evidence),
            time_remaining_s=remaining_s,
            max_time_s=challenge.max_time_s,
            available_models=list(available_models),
            tools_used=sorted(ledger.used_tools),
            tokens_used=tokens_used,
            required_tools=sorted(ledger.required_tools),
        )

    def _image_arguments(
        self,
        tool_name: str,
        definitions: list[Any],
        *,
        prompt: str,
        input_image_uri: str,
        model_name: str,
    ) -> dict[str, Any]:
        schema: dict[str, Any] = {}
        for tool in self._discovered_tools(definitions):
            if tool.name == tool_name:
                schema = tool.input_schema
                break
        properties = schema.get("properties") if isinstance(schema, dict) else {}
        allowed = set(properties) if isinstance(properties, dict) else set()
        candidates: dict[str, Any] = {
            "agent_id": self.agent_id,
            "prompt": prompt,
            "question": prompt,
            "image_uri": input_image_uri,
            "model": model_name,
        }
        return {
            key: value
            for key, value in candidates.items()
            if key in allowed and str(value).strip()
        }

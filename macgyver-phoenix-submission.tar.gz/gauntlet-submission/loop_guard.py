"""State-aware retry and deadline protection for the Gauntlet controller."""

from __future__ import annotations

import json
from dataclasses import dataclass
from enum import StrEnum
from typing import Any


class ActionKind(StrEnum):
    """Kinds of controller action with different repetition rules."""

    CAPABILITY = "capability"
    DISCOVERY = "discovery"
    STATUS = "status"
    REGISTER = "register"
    SUBMIT = "submit"


@dataclass(frozen=True)
class GuardedAction:
    """One proposed action before the controller executes it."""

    name: str
    arguments: dict[str, Any]
    kind: ActionKind = ActionKind.CAPABILITY

    @property
    def fingerprint(self) -> str:
        """Return a stable identity for duplicate-action checks."""
        encoded = json.dumps(self.arguments, sort_keys=True, default=str, separators=(",", ":"))
        return f"{self.kind}:{self.name}:{encoded}"


@dataclass(frozen=True)
class GuardDecision:
    """Explain whether a proposed action is safe to run."""

    allowed: bool
    reason: str


class LoopGuard:
    """Bound failed repetition while preserving legitimate recovery calls."""

    def __init__(
        self,
        *,
        max_failed_attempts: int = 2,
        max_no_progress_steps: int = 3,
        submission_reserve_s: float = 20.0,
    ) -> None:
        if max_failed_attempts < 1 or max_no_progress_steps < 1:
            raise ValueError("Retry and no-progress limits must be positive")
        self.max_failed_attempts = max_failed_attempts
        self.max_no_progress_steps = max_no_progress_steps
        self.submission_reserve_s = max(0.0, submission_reserve_s)
        self._failed_attempts: dict[str, int] = {}
        self._last_evidence_version = 0
        self._no_progress_steps = 0
        self._registered = False
        self._submitted_answer: str | None = None
        self._submission_uncertain = False

    def check(self, action: GuardedAction, *, evidence_version: int) -> GuardDecision:
        """Check an action against registration, submission, and retry contracts."""
        if action.kind is ActionKind.REGISTER and self._registered:
            return GuardDecision(False, "Registration already completed for this run")

        if action.kind is ActionKind.SUBMIT and self._submitted_answer is not None:
            answer = str(action.arguments.get("answer") or "").strip()
            if answer != self._submitted_answer:
                return GuardDecision(False, "A different answer cannot replace the first submission")
            if not self._submission_uncertain:
                return GuardDecision(False, "The final submission is already confirmed")
            return GuardDecision(True, "Exact-answer retry allowed after uncertain delivery")

        # Discovery and status calls may repeat because their remote state changes over time.
        if action.kind in {ActionKind.DISCOVERY, ActionKind.STATUS}:
            return GuardDecision(True, "State-reading calls are intentionally repeatable")

        failures = self._failed_attempts.get(action.fingerprint, 0)
        if failures >= self.max_failed_attempts and evidence_version == self._last_evidence_version:
            return GuardDecision(False, "Repeated failed action has produced no new evidence")
        if self._no_progress_steps >= self.max_no_progress_steps:
            return GuardDecision(False, "No-progress budget exhausted; choose another route")
        return GuardDecision(True, "Action is within the retry and progress budgets")

    def record_registration(self) -> None:
        """Remember that the one allowed registration completed."""
        self._registered = True

    def record_result(
        self,
        action: GuardedAction,
        *,
        succeeded: bool,
        evidence_version: int,
    ) -> None:
        """Update failure and progress counters after an observable result."""
        if succeeded:
            self._failed_attempts.pop(action.fingerprint, None)
        else:
            self._failed_attempts[action.fingerprint] = (
                self._failed_attempts.get(action.fingerprint, 0) + 1
            )

        if evidence_version > self._last_evidence_version:
            self._last_evidence_version = evidence_version
            self._no_progress_steps = 0
        else:
            self._no_progress_steps += 1

    def record_submission(self, answer: str, *, delivery_confirmed: bool) -> None:
        """Record the canonical answer and whether a receipt was received."""
        clean_answer = answer.strip()
        if not clean_answer:
            raise ValueError("Cannot record an empty final answer")
        if self._submitted_answer is not None and clean_answer != self._submitted_answer:
            raise ValueError("Cannot replace the first submitted answer")
        self._submitted_answer = clean_answer
        self._submission_uncertain = not delivery_confirmed

    def should_submit(self, remaining_s: float, *, has_candidate: bool) -> bool:
        """Reserve authoritative arena time for drafting and final submission."""
        return has_candidate and remaining_s <= self.submission_reserve_s

    def call_timeout(self, remaining_s: float, *, preferred_s: float = 30.0) -> float:
        """Bound a network/model call while preserving the submission reserve."""
        usable = remaining_s - self.submission_reserve_s
        return max(0.0, min(preferred_s, usable))

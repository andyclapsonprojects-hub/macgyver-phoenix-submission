"""Private, opt-in recorder for our own Practice puzzle evidence."""

from __future__ import annotations

import hashlib
import json
import os
import re
from dataclasses import asdict, is_dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

_SECRET_KEY = re.compile(
    r"(?:^|[_-])(?:api[_-]?key|access[_-]?token|refresh[_-]?token|secret|password|authorization)(?:$|[_-])",
    re.IGNORECASE,
)
_SAFE_NAME = re.compile(r"[^A-Za-z0-9_.-]+")


class PrivatePuzzleRecorder:
    """Write one private JSON record when explicitly enabled by environment."""

    def __init__(self, root: Path, *, enabled: bool) -> None:
        self.root = root
        self.enabled = enabled
        self.path: Path | None = None
        self.record: dict[str, Any] = {}

    @classmethod
    def from_environment(cls, repo_root: Path) -> PrivatePuzzleRecorder:
        """Create a recorder; recording is off unless explicitly requested."""
        enabled = os.getenv("PRIVATE_PUZZLE_RECORDING", "").strip().lower() in {
            "1",
            "true",
            "yes",
        }
        configured = os.getenv("PRIVATE_PUZZLE_RECORD_DIR", "").strip()
        root = Path(configured) if configured else repo_root / ".private" / "puzzles"
        return cls(root, enabled=enabled)

    def start_text(
        self,
        *,
        agent_id: str,
        challenge: Any,
        clues: list[dict[str, str]],
    ) -> None:
        """Capture the exact text challenge and ordered clue identifiers/text."""
        self._start(
            agent_id=agent_id,
            modality="text",
            challenge=challenge,
            clues=clues,
        )

    def start_image(self, *, agent_id: str, challenge: Any) -> None:
        """Capture the image challenge without copying inline image bytes."""
        self._start(
            agent_id=agent_id,
            modality="image",
            challenge=challenge,
            clues=[],
        )

    def finish(self, *, answer: str, model_name: str, receipt: Any) -> None:
        """Attach our answer and canonical receipt, then atomically rewrite JSON."""
        if not self.enabled or self.path is None:
            return
        self.record["completed_at_utc"] = datetime.now(UTC).isoformat()
        self.record["answer"] = self._safe_value(answer)
        self.record["model_name"] = model_name
        self.record["receipt"] = self._safe_value(receipt)
        self._write()

    def _start(
        self,
        *,
        agent_id: str,
        modality: str,
        challenge: Any,
        clues: list[dict[str, str]],
    ) -> None:
        if not self.enabled:
            return
        now = datetime.now(UTC)
        puzzle_id = str(getattr(challenge, "puzzle_id", "unknown") or "unknown")
        safe_puzzle = _SAFE_NAME.sub("-", puzzle_id).strip("-")[:80] or "unknown"
        self.root.mkdir(parents=True, exist_ok=True)
        self.path = self.root / f"{now:%Y%m%dT%H%M%S%fZ}-{safe_puzzle}.json"
        self.record = {
            "schema_version": 1,
            "private_evaluation_only": True,
            "captured_at_utc": now.isoformat(),
            "agent_id": agent_id,
            "modality": modality,
            "challenge": self._safe_value(challenge),
            "clues_in_server_order": self._safe_value(clues),
        }
        self._write()

    def _write(self) -> None:
        if self.path is None:
            return
        temporary = self.path.with_suffix(".json.tmp")
        temporary.write_text(
            json.dumps(self.record, indent=2, ensure_ascii=False, default=str),
            encoding="utf-8",
        )
        temporary.replace(self.path)

    @classmethod
    def _safe_value(cls, value: Any, *, key: str = "") -> Any:
        if _SECRET_KEY.search(key):
            return "[REDACTED]"
        if is_dataclass(value) and not isinstance(value, type):
            return cls._safe_value(asdict(value), key=key)
        if isinstance(value, dict):
            return {
                str(item_key): cls._safe_value(item_value, key=str(item_key))
                for item_key, item_value in value.items()
            }
        if isinstance(value, (list, tuple, set)):
            return [cls._safe_value(item, key=key) for item in value]
        if hasattr(value, "__dict__"):
            return cls._safe_value(vars(value), key=key)
        if isinstance(value, str) and value.startswith("data:"):
            digest = hashlib.sha256(value.encode("utf-8")).hexdigest()
            return f"[inline data omitted; sha256={digest}]"
        return value

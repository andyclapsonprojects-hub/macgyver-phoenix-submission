#!/usr/bin/env python3
"""Competition entrypoint for the lightweight MacGyver Agent."""

from __future__ import annotations

import argparse
import asyncio

from macgyver_runtime import run_connected


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the MacGyver Gauntlet agent")
    parser.add_argument(
        "--offline-check",
        action="store_true",
        help="Import the complete controller without loading credentials or connecting",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume the existing registered session without registering again",
    )
    return parser


def main() -> None:
    """Run an import-only check or the connected competition entrypoint."""
    args = _parser().parse_args()
    if args.offline_check:
        print("Offline check passed: MacGyver controller imports successfully.")
        return
    asyncio.run(run_connected(resume=args.resume))


if __name__ == "__main__":
    main()

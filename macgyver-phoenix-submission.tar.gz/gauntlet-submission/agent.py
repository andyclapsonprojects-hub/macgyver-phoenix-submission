#!/usr/bin/env python3
"""Competition entrypoint for the lightweight MacGyver Agent."""

from __future__ import annotations

import argparse
import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv

from arena_clients import (
    HttpArenaClient,
    McpArenaClient,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
)
from arena_clients.config import agent_id_problem
from arena_clients.proxy_headers import build_proxy_headers
from controller import ThorntonController
from macgyver_strategy import MacGyverStrategy
from model_selector import fetch_available_models

REPO_ROOT = Path(__file__).resolve().parent


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the MacGyver Gauntlet agent")
    parser.add_argument(
        "--offline-check",
        action="store_true",
        help="Import the complete controller without loading credentials or connecting",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume the existing registered session without registering again",
    )
    return parser


async def _run_connected(*, resume: bool = False) -> None:
    """Create official clients and hand the run to ThorntonController."""
    load_dotenv(REPO_ROOT / ".env")
    strategy = MacGyverStrategy()
    agent_id = str(os.getenv("AGENT_ID") or strategy.agent_id).strip()
    agent_name = str(os.getenv("AGENT_NAME") or strategy.agent_name).strip()
    problem = agent_id_problem(agent_id)
    if problem:
        raise SystemExit(problem)
    os.environ["AGENT_ID"] = agent_id
    os.environ["AGENT_NAME"] = agent_name

    ensure_connected()
    api_key = get_arena_api_key()
    proxy_host = get_proxy_host()
    http_client = HttpArenaClient(get_api_base(), api_key)

    try:
        from openai import OpenAI
    except ImportError as error:
        raise RuntimeError("The locked runtime is missing the openai package") from error

    def llm_client_factory(usage_scope: str | None):
        return OpenAI(
            base_url=proxy_host,
            api_key=api_key,
            default_headers=build_proxy_headers(agent_id, usage_scope),
        )

    async with McpArenaClient(get_mcp_url()) as mcp_client:
        controller = ThorntonController(
            strategy=strategy,
            http_client=http_client,
            mcp_client=mcp_client,
            llm_client_factory=llm_client_factory,
            fetch_models=lambda: fetch_available_models(proxy_host, api_key),
            agent_id=agent_id,
            agent_name=agent_name,
        )
        outcome = await controller.run(register_session=not resume)
    print(f"Status: submitted ({outcome.modality})")
    print(f"Model: {outcome.model_name}")


def main() -> None:
    """Run an import-only check or the connected competition entrypoint."""
    args = _parser().parse_args()
    if args.offline_check:
        print("Offline check passed: MacGyver controller imports successfully.")
        return
    asyncio.run(_run_connected(resume=args.resume))


if __name__ == "__main__":
    main()

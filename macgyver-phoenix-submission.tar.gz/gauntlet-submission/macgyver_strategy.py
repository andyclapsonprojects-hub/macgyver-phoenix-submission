"""Resourceful, competition-safe strategy settings for the Gauntlet agent."""

from __future__ import annotations

from base_strategy import BaseStrategy, ChallengeContext

PROMPT_CONTRACT_VERSION = "macgyver-json-v2"
IMAGE_PROMPT_CONTRACT_VERSION = "macgyver-image-v6-poster-composition"
_WHOLE_IMAGE_EDIT_PHRASES = (
    "adjust the lighting",
    "change the background",
    "change the entire image",
    "change the full image",
    "change the lighting",
    "change the scene",
    "change the season",
    "change the sky",
    "change the time of day",
    "change the weather",
    "change the whole image",
    "make the background",
    "replace the background",
    "replace the sky",
    "style transfer",
)
_NO_TEXT_PHRASES = (
    "no text",
    "without text",
    "avoid text",
    "no logo",
    "no watermark",
)


class MacGyverStrategy(BaseStrategy):
    """Choose a simple, evidence-led route from the resources available at runtime."""

    # Keep one identity across Practice, packaging, and the live event.
    agent_id = "macgyver-phoenix"
    agent_name = "MacGyver Agent"
    prompt_contract_version = PROMPT_CONTRACT_VERSION

    text_system_prompt = (
        "You are MacGyver, a resourceful challenge solver. Use only evidence, "
        "tools, and models available in this run. Follow every challenge rule "
        "exactly. Return exactly one JSON object matching the decision shapes "
        "in the user prompt, with no markdown or commentary. Never invent a "
        "tool or unsupported fact. Preserve the final answer's exact required "
        "structure inside the JSON answer field. Encode line breaks as \\n inside "
        "that JSON string; never place literal line breaks inside a JSON string. "
        "Do not expose hidden reasoning."
    )
    text_strategy_notes = (
        "Prefer the shortest evidence-backed route and preserve the required "
        "answer format exactly."
    )
    text_temperature = 0.0
    text_max_tokens = 8192

    image_strategy_notes = (
        "Prefer image_edit when a valid input image is available. Preserve the "
        "source unless the challenge asks for a change, and use standard "
        "resolution to protect time and transport reliability."
    )
    image_prompt_contract_version = IMAGE_PROMPT_CONTRACT_VERSION

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        """Give image models one primary instruction and an explicit constraint list."""
        instruction = (
            ctx.challenge_text.strip()
            or ctx.description.strip()
            or ctx.rules.strip()
            or "Produce the requested image result."
        )
        reference_constraints = ctx.rules.strip()

        if "edit" in ctx.challenge_type.lower() or bool(ctx.image_url):
            sections = [
                "PRIMARY EDIT INSTRUCTION - follow every explicit requirement exactly:",
                instruction,
                "",
                "PRESERVATION CONSTRAINTS:",
            ]
            if reference_constraints and reference_constraints not in instruction:
                sections.append(reference_constraints)
            if any(
                phrase in instruction.casefold() for phrase in _WHOLE_IMAGE_EDIT_PHRASES
            ):
                sections.extend(
                    [
                        (
                            "Change only what the primary instruction requests. Preserve every "
                            "subject, identity, text element, object, position, layout, framing, "
                            "colour, lighting, texture, style, and image-quality characteristic "
                            "that the requested whole-image change does not require altering."
                        ),
                        "Do not add, remove, replace, crop, or move unrelated content.",
                    ]
                )
            else:
                sections.extend(
                    [
                        (
                            "Treat the supplied source image as an immutable canvas. Apply the requested "
                            "change as a localized inpainting edit in the smallest feasible region around "
                            "the named target; do not regenerate or reinterpret the full image."
                        ),
                        (
                            "Outside that local edit region, keep the source unchanged: preserve every "
                            "subject, identity, text element, object, position, layout, framing, colour, "
                            "lighting, texture, style, background detail, and image-quality characteristic."
                        ),
                        (
                            "Do not apply any whole-image processing outside the edit region: no global "
                            "colour grading, relighting, exposure, contrast, tone, sharpening, smoothing, "
                            "denoising, resampling, reframing, or compression change."
                        ),
                        "Do not add, remove, replace, crop, restyle, recolour, or move unrelated content.",
                    ]
                )
            sections.extend(
                [
                    "",
                    "FINAL CHECK:",
                    (
                        "Verify every requested change is visible and every unrequested region still "
                        "matches the source. Return one standard-resolution edited image only."
                    ),
                ]
            )
            return "\n".join(sections)

        sections = [
            "PRIMARY GENERATION INSTRUCTION - follow every explicit requirement exactly:",
            instruction,
        ]
        if reference_constraints and reference_constraints not in instruction:
            sections.extend(["", "OUTPUT CONSTRAINTS:", reference_constraints])
        combined_request = f"{instruction}\n{reference_constraints}".casefold()
        if any(phrase in combined_request for phrase in _NO_TEXT_PHRASES):
            sections.extend(
                [
                    "",
                    "NO-TEXT INSPECTION:",
                    (
                        "The final image must contain zero visible letters, words, numbers, logos, "
                        "labels, captions, signs, emblems, or watermarks. Inspect the entire image "
                        "and remove any text-like marks before returning it."
                    ),
                ]
            )
        if "poster" in combined_request:
            sections.extend(
                [
                    "",
                    "POSTER COMPOSITION:",
                    (
                        "Use one dominant focal subject, a strong visual hierarchy, balanced negative "
                        "space, clear depth, and a deliberate cinematic camera angle. Make the requested "
                        "theme immediately readable from the imagery alone."
                    ),
                ]
            )
        sections.extend(
            [
                "",
                "FINAL CHECK:",
                (
                    "Verify the image satisfies every requested subject, relationship, style, and "
                    "negative constraint. Return one coherent standard-resolution image only."
                ),
            ]
        )
        return "\n".join(sections)

    def rank_models(
        self,
        ctx: ChallengeContext,
        available_models: list[str],
    ) -> list[str]:
        """Prefer measured text models and test a stronger image-quality tier."""
        if self.is_image_challenge(ctx):
            image_order = (
                "gemini-3-pro-image",
                "gemini-3.1-flash-image",
                "gemini-3.1-flash-lite-image",
            )
            preferred = [name for name in image_order if name in available_models]
            return preferred + [
                name for name in available_models if name not in preferred
            ]
        if ctx.max_time_s >= 90:
            measured_order = (
                "gemini-3.8-flash",
                "qwen3.7-flash",
                "nemotron-3.5-lightning",
            )
        else:
            measured_order = ("qwen3.7-flash", "nemotron-3.5-lightning")
        preferred = [name for name in measured_order if name in available_models]
        return preferred + [name for name in available_models if name not in preferred]

"""Resourceful, competition-safe strategy settings for the Gauntlet agent."""

from __future__ import annotations

from base_strategy import BaseStrategy, ChallengeContext

PROMPT_CONTRACT_VERSION = "macgyver-json-v2"
IMAGE_PROMPT_CONTRACT_VERSION = "macgyver-image-v1"


class MacGyverStrategy(BaseStrategy):
    """Choose a simple, evidence-led route from the resources available at runtime."""

    # Keep one identity across Practice, packaging, and the live event.
    agent_id = "macgyver-phoenix"
    agent_name = "MacGyver Agent"
    prompt_contract_version = PROMPT_CONTRACT_VERSION

    text_system_prompt = (
        "You are MacGyver, a resourceful challenge solver. Use only evidence, "
        "tools, and models available in this run. Follow every challenge rule "
        "exactly. Return exactly one JSON object matching the decision shapes "
        "in the user prompt, with no markdown or commentary. Never invent a "
        "tool or unsupported fact. Preserve the final answer's exact required "
        "structure inside the JSON answer field. Encode line breaks as \\n inside "
        "that JSON string; never place literal line breaks inside a JSON string. "
        "Do not expose hidden reasoning."
    )
    text_strategy_notes = (
        "Prefer the shortest evidence-backed route and preserve the required "
        "answer format exactly."
    )
    text_temperature = 0.0
    text_max_tokens = 8192

    image_strategy_notes = (
        "Prefer image_edit when a valid input image is available. Preserve the "
        "source unless the challenge asks for a change, and use standard "
        "resolution to protect time and transport reliability."
    )
    image_prompt_contract_version = IMAGE_PROMPT_CONTRACT_VERSION

    def build_image_prompt(self, ctx: ChallengeContext) -> str:
        """Preserve the challenge wording while making edit boundaries explicit."""
        instruction = ctx.rules.strip() or ctx.challenge_text.strip() or ctx.description.strip()
        context = ctx.challenge_text.strip() or ctx.description.strip()
        sections = [
            "PRIMARY INSTRUCTION — follow every explicit requirement exactly:",
            instruction or "Produce the requested image result.",
            "",
            "EDIT BOUNDARY:",
            (
                "Change only what the primary instruction explicitly requests. Preserve all other "
                "subjects, identities, text, objects, layout, framing, colours, lighting, style, "
                "background, and image quality unless the instruction explicitly says otherwise."
            ),
            "Do not add, remove, replace, crop, restyle, or move unrelated content.",
            "",
            "FINAL CHECK BEFORE OUTPUT:",
            (
                "Confirm every requested change is present and every unrequested region remains "
                "visually consistent with the source. Return one standard-resolution image only."
            ),
        ]
        if context and context not in instruction:
            sections[2:2] = ["", f"Context: {context}"]
        return "\n".join(sections)

    def rank_models(
        self,
        ctx: ChallengeContext,
        available_models: list[str],
    ) -> list[str]:
        """Prefer the text model that followed the measured JSON contract."""
        if self.is_image_challenge(ctx):
            return super().rank_models(ctx, available_models)
        measured_order = ("qwen3.7-flash", "nemotron-3.5-lightning")
        preferred = [name for name in measured_order if name in available_models]
        return preferred + [name for name in available_models if name not in preferred]

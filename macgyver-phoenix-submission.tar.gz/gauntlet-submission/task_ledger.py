"""Small in-memory mission ledger for tasks, evidence, and attempted actions."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class MissionStatus(StrEnum):
    """Lifecycle states used by the agent's current objective."""

    NEW = "NEW"
    ACTIVE = "ACTIVE"
    VERIFYING = "VERIFYING"
    SOLVED = "SOLVED"
    BLOCKED = "BLOCKED"


@dataclass(frozen=True)
class ActionRecord:
    """One attempted tool or model action and its observable result."""

    name: str
    arguments: dict[str, Any]
    succeeded: bool
    result_summary: str


@dataclass
class PhoenixLedger:
    """Hold the mission plan and evidence that survives between agent steps."""

    objective: str
    required_tools: set[str] = field(default_factory=set)
    used_tools: set[str] = field(default_factory=set)
    evidence: list[str] = field(default_factory=list)
    attempts: list[ActionRecord] = field(default_factory=list)
    candidate_answer: str = ""
    status: MissionStatus = MissionStatus.NEW

    def activate(self) -> None:
        """Move a new mission into active work."""
        if self.status is MissionStatus.NEW:
            self.status = MissionStatus.ACTIVE

    def require_tools(self, tool_names: list[str]) -> None:
        """Record every challenge-mandated tool without imposing a tool-count cap."""
        self.required_tools.update(name for name in tool_names if name.strip())

    def record_tool_action(
        self,
        name: str,
        arguments: dict[str, Any],
        *,
        succeeded: bool,
        result_summary: str,
    ) -> None:
        """Add one auditable tool attempt and mark successful tool use."""
        self.attempts.append(
            ActionRecord(
                name=name,
                arguments=dict(arguments),
                succeeded=succeeded,
                result_summary=result_summary,
            )
        )
        if succeeded:
            self.used_tools.add(name)

    def add_evidence(self, fact: str) -> None:
        """Keep a new non-empty fact once, preserving discovery order."""
        clean_fact = fact.strip()
        if clean_fact and clean_fact not in self.evidence:
            self.evidence.append(clean_fact)

    def set_candidate(self, answer: str) -> None:
        """Store the strongest current answer without declaring it solved."""
        clean_answer = answer.strip()
        if not clean_answer:
            return
        self.candidate_answer = clean_answer
        self.status = MissionStatus.VERIFYING

    def missing_required_tools(self) -> set[str]:
        """Return required tool names not yet completed successfully."""
        return self.required_tools - self.used_tools

    def mark_solved(self) -> None:
        """Mark the mission solved only when a candidate and required tools exist."""
        if not self.candidate_answer:
            raise ValueError("Cannot solve a mission without a candidate answer")
        missing = self.missing_required_tools()
        if missing:
            raise ValueError(f"Cannot solve mission; required tools are missing: {sorted(missing)}")
        self.status = MissionStatus.SOLVED

    def mark_blocked(self) -> None:
        """Stop the current route while preserving its evidence and attempts."""
        self.status = MissionStatus.BLOCKED

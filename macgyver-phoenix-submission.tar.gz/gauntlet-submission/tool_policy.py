"""Runtime MCP tool discovery and argument validation."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any

from jsonschema import Draft202012Validator
from jsonschema.exceptions import SchemaError, ValidationError


class ToolPolicyError(ValueError):
    """Base error for a proposed tool action that is unsafe to execute."""


class UnknownToolError(ToolPolicyError):
    """Raised when the model proposes a tool absent from runtime discovery."""


class InvalidToolArguments(ToolPolicyError):
    """Raised when proposed arguments do not match the discovered JSON schema."""


@dataclass(frozen=True)
class DiscoveredTool:
    """The name and input contract advertised by one MCP tool."""

    name: str
    input_schema: dict[str, Any]


def _read_field(definition: Any, *names: str) -> Any:
    """Read a field from either an MCP object or its dictionary representation."""
    for name in names:
        if isinstance(definition, dict) and name in definition:
            return definition[name]
        if hasattr(definition, name):
            return getattr(definition, name)
    return None


class DaltonToolScout:
    """Catalogue live MCP tools and validate actions before execution."""

    def __init__(self, tools: Iterable[DiscoveredTool]) -> None:
        self._tools = {tool.name: tool for tool in tools if tool.name}

    @classmethod
    def from_runtime_definitions(cls, definitions: Iterable[Any]) -> DaltonToolScout:
        """Build a catalogue from definitions returned by MCP ``list_tools``."""
        tools: list[DiscoveredTool] = []
        for definition in definitions:
            name = str(_read_field(definition, "name") or "").strip()
            schema = _read_field(definition, "inputSchema", "input_schema") or {}
            if not name or not isinstance(schema, dict):
                continue
            try:
                Draft202012Validator.check_schema(schema)
            except SchemaError as error:
                raise ToolPolicyError(f"Tool {name!r} advertised an invalid input schema") from error
            tools.append(DiscoveredTool(name=name, input_schema=schema))
        return cls(tools)

    @property
    def available_tools(self) -> tuple[str, ...]:
        """Return all currently discovered tool names without imposing a cap."""
        return tuple(self._tools)

    def validate_action(self, name: str, arguments: dict[str, Any]) -> None:
        """Reject unavailable tools and arguments outside the advertised schema."""
        tool = self._tools.get(name)
        if tool is None:
            raise UnknownToolError(f"Tool {name!r} was not discovered in this run")
        try:
            Draft202012Validator(tool.input_schema).validate(arguments)
        except ValidationError as error:
            location = ".".join(str(part) for part in error.absolute_path) or "arguments"
            raise InvalidToolArguments(
                f"Invalid arguments for {name!r} at {location}: {error.message}"
            ) from error

    def ordered_plan(
        self,
        required_tools: Iterable[str],
        proposed_tools: Iterable[str],
    ) -> list[str]:
        """Put required discovered tools first, then useful discovered proposals."""
        plan: list[str] = []
        for name in (*tuple(required_tools), *tuple(proposed_tools)):
            if name in self._tools and name not in plan:
                plan.append(name)
        return plan

    def missing_required_tools(self, required_tools: Iterable[str]) -> set[str]:
        """Identify challenge requirements absent from the live MCP catalogue."""
        return {name for name in required_tools if name not in self._tools}

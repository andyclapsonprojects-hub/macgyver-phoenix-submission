"""Deterministic answer checks kept separate from model judgement."""

from __future__ import annotations

import base64
import binascii
import re
from dataclasses import dataclass
from enum import StrEnum
from urllib.parse import urlparse


class AnswerModality(StrEnum):
    """Submission shapes with different fallback rules."""

    TEXT = "text"
    IMAGE_EDIT = "image_edit"
    IMAGE_GENERATE = "image_generate"


@dataclass(frozen=True)
class ValidationResult:
    """A normalized candidate plus deterministic validation errors."""

    valid: bool
    normalized_answer: str
    errors: tuple[str, ...] = ()


class RileyValidator:
    """Validate answer shape and required-tool completion without another LLM."""

    @staticmethod
    def normalize_text(answer: str) -> str:
        """Remove one ANSWER prefix while preserving multiline content exactly."""
        clean = answer.strip()
        if not clean:
            return ""
        first, separator, remainder = clean.partition("\n")
        if first.casefold().startswith("answer:"):
            first_value = first.split(":", 1)[1].strip()
            return first_value + (separator + remainder if remainder else "")
        return clean

    def validate_text(
        self,
        answer: str,
        *,
        required_tools: set[str] | None = None,
        used_tools: set[str] | None = None,
    ) -> ValidationResult:
        """Require a real text candidate and every challenge-mandated tool."""
        normalized = self.normalize_text(answer)
        errors: list[str] = []
        if not normalized:
            errors.append("Text answer is empty")
        if normalized.casefold() in {"unknown", "none", "n/a"}:
            errors.append("Text answer is only a placeholder")
        missing = set(required_tools or ()) - set(used_tools or ())
        if missing:
            errors.append(f"Required tools not completed: {sorted(missing)}")
        return ValidationResult(not errors, normalized, tuple(errors))

    def validate_image(
        self,
        image_uri: str,
        *,
        modality: AnswerModality,
        input_image_uri: str = "",
        required_tools: set[str] | None = None,
        used_tools: set[str] | None = None,
    ) -> ValidationResult:
        """Validate image transport and modality-specific fallback behaviour."""
        normalized = image_uri.strip()
        errors: list[str] = []
        if not normalized:
            errors.append("Image URI is empty")
        elif not self._is_supported_image_uri(normalized):
            errors.append("Image URI must be HTTPS or a data:image URI")
        if normalized and input_image_uri.strip() and normalized == input_image_uri.strip():
            errors.append(f"{modality.value} cannot submit an unchanged input image")
        missing = set(required_tools or ()) - set(used_tools or ())
        if missing:
            errors.append(f"Required tools not completed: {sorted(missing)}")
        return ValidationResult(not errors, normalized, tuple(errors))

    @staticmethod
    def _is_supported_image_uri(value: str) -> bool:
        if value.startswith("data:image/"):
            try:
                header, payload = value.split(",", 1)
            except ValueError:
                return False
            media_type = header.removeprefix("data:").removesuffix(";base64")
            subtype = media_type.removeprefix("image/")
            if (
                not header.endswith(";base64")
                or not re.fullmatch(r"[A-Za-z0-9.+-]+", subtype)
                or not payload
            ):
                return False
            try:
                return bool(base64.b64decode(payload, validate=True))
            except (binascii.Error, ValueError):
                return False
        parsed = urlparse(value)
        return parsed.scheme == "https" and bool(parsed.netloc)
